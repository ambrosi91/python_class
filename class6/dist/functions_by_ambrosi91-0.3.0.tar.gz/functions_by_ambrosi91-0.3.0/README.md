# Instructions

#### This is our test project
#### Please install this package
```
pip install functions-by-ambrosi91
```

#### You can also install older packages
```
pip install functions-by-ambrosi91==VERSION_NUMBER
```